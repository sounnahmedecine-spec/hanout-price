export const firebaseConfig = {
  "projectId": "studio-9692019390-ae379",
  "appId": "1:723446816365:web:263aa1738e22adb1406964",
  "storageBucket": "studio-9692019390-ae379.firebasestorage.app",
  "apiKey": "AIzaSyCAj63G6bydOxrfHTuGSP8cNxOq_RnZjF0",
  "authDomain": "studio-9692019390-ae379.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "723446816365"
};
