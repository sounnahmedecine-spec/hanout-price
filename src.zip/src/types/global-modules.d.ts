declare module "embla-carousel-react" {
  const useEmblaCarousel: any;
  export default useEmblaCarousel;
  export type UseEmblaCarouselType = any;
}

declare module "react-day-picker" {
  const DayPicker: any;
  export { DayPicker };
}